"use client";
import React, { createContext, useContext, useState, useEffect } from "react";

// Define context and types
interface SearchQueryContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const SearchQueryContext = createContext<SearchQueryContextType | undefined>(
  undefined
);

export const useSearchQuery = () => {
  const context = useContext(SearchQueryContext);
  if (!context) {
    throw new Error("useSearchQuery must be used within a SearchQueryProvider");
  }
  return context;
};

export const SearchQueryProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);

  // Debounce the search query update to reduce excessive updates
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300); // Adjust debounce delay as necessary (300ms is a good starting point)

    return () => clearTimeout(timeoutId); // Cleanup timeout on component unmount or query change
  }, [searchQuery]);

  return (
    <SearchQueryContext.Provider
      value={{ searchQuery: debouncedQuery, setSearchQuery }}
    >
      {children}
    </SearchQueryContext.Provider>
  );
};
