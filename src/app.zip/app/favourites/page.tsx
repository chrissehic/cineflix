"use client"

import { useEffect, useState } from "react"
import { useMovie } from "@/context/MovieContext"
import { useFavorites } from "@/context/FavoritesContext"
import { MovieGrid } from "@/components/MovieGrid"
import { Movie } from "@/lib/api"

export default function Favourites() {
  const { movies, isLoading, error } = useMovie() // Get movies from context
  const { favorites } = useFavorites() // Get favorites from context
  const [initialized, setInitialized] = useState(false)
  const [favoriteMovies, setFavoriteMovies] = useState<Movie[]>([]) // Store favorite movies

  // Filter the movies that are in favorites after the movies are fetched
  useEffect(() => {
    if (movies.length > 0 && favorites.length > 0) {
      const filteredFavorites = movies.filter((movie) =>
        favorites.includes(movie.imdbID) // Check if movie is in favorites
      )
      setFavoriteMovies(filteredFavorites) // Set the filtered favorite movies
      setInitialized(true) // Set initialized once filtering is done
    } else if (favorites.length === 0) {
      setInitialized(true) // If no favorites, still mark as initialized
    }
  }, [movies, favorites]) // Re-run when movies or favorites change

  return (
    <div className="py-4">
      <h1 className="text-2xl font-bold mb-8">Favourites</h1>

      {/* Loading state */}
      {!initialized ? (
        <p>Loading your favourites...</p>
      ) : favoriteMovies.length === 0 ? (
        <p>No favorite movies yet. Start adding some!</p> // Empty state for no favorites
      ) : (
        // Pass filtered favorite movies to MovieGrid component
        <MovieGrid
          movies={favoriteMovies} // Only pass the favorite movies
          isLoading={isLoading}
          error={error}
          showOnlyFavorites={true} // Show only favorited movies
          favoritesEmptyMessage="You haven't added any favorites yet. Start adding some!"
        />
      )}
    </div>
  )
}
